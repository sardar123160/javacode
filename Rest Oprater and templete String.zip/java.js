var a= 20;
var b =30;
var c=Math.max(a,b);
console.log(c);

// var sum =(a,b,c) => {
// console.log(arguments);
// };
// sum(20,30,40);



var ary1=[20,30];
var ary2=[50,40];
var ary3=[40,80];
 var aryall =[...ary1,...ary2,200,...ary3];
console.log(aryall);


var ary1={
    firstname:"sardar"
};
var ary2={
    lastname:"meghani"
};
var ary3={
    surname:"bheel"
};
 var aryall ={...ary1,...ary2,...ary3};
console.log(aryall);

function sum(name,...num){
    console.log(name);
    console.log(num);
    var sum = 0;
    for (let i in arguments){
        sum+=arguments[i];
    }
    console.log(sum);
    for(let i in num){
        sum+=num[i];
    };
    console.log(`username : ${sum}`);
}
